package http.websocket.exceptions;

public class WebsocketNotConnectedException extends RuntimeException {

}
