package driver;

import driver.protocol.ProtocolException;
import driver.channels.Channel;

import static driver.Index.T13;

public class RGB {

    public static void setRGB(int value, boolean left, boolean right) throws ProtocolException {

        int r = (value) & 0xFF;
        int g = (value >> 8) & 0xFF;
        int b = (value >> 16) & 0xFF;
        int a = (value >> 24) & 0xFF;

        int color = 0;

        if (left) {
            T13.C1.setValue(4095 * b / 255, 0);
            T13.C2.setValue(4095 * g / 255, 0);
            T13.C3.setValue(4095 * r / 255, 0);
        }

        if (right) {
            T13.C4.setValue(4095 * r / 255, 0);
            T13.C5.setValue(4095 * g / 255, 0);
            T13.C6.setValue(4095 * b / 255, 0);
        }

        // 1 - L B
        // 2 - L G
        // 3 - L R
        //4 - R R
        // 5 - R G
        // 6 - L B
    }

}
