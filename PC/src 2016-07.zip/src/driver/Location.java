package driver;

public enum Location {

    HALL("Korytarz"),
    KITCHEN("Kuchnia"),
    BEDROM("Sypialnia"),
    ROOM("Pokój dziecięcy"),
    SALON("Salon"),
    BATHROM("Łazienka");

    public final String name;

    private Location(String name) {
        this.name = name;
    }

}
