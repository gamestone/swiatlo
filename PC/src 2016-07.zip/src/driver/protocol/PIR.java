package driver.protocol;

import com.threads.TThread;
import java.util.Calendar;
import java.util.Date;
import mlogger.Log;

public class PIR extends TThread {

    boolean pirEnabled;
    long powerOnTS;
    private final Helper helper;
    long flushTS;
    boolean bright;
    private final Object flushNotify = new Object();

    final static int POWER_ON_DELAY = 15000;
    final static int BRIGHT_TIME = 25000;

    public void flush() {
        if (!(helper.pirPower && System.currentTimeMillis() - powerOnTS > POWER_ON_DELAY))
            return;

        flushTS = System.currentTimeMillis();
        synchronized (flushNotify) {
            flushNotify.notifyAll();
        }
    }

    public PIR(Helper helper) {
        this.helper = helper;
    }

    static int getMinute(double day, double hMin, double hMax) {

        hMin *= 60;
        hMax *= 60;

        day += 10;
        if (day > 365)
            day = day - 365;
        day = 182 - Math.abs(day - 182);

        double d = (hMax - hMin) / hMax;

        // day =  day / 182.5d
        day = (1 - Math.cos((day / 182.5d) * Math.PI)) / 2d;

        return (int) (hMin + hMax * d * day);
    }

    private final static double WINTER_ON = 15.6;
    private final static double WINTER_OFF = 21;
    private final static double SUMMER_ON = 21;
    private final static double SUMMER_OFF = 23.5;

    boolean shouldBeActive() {

        Calendar cal = Calendar.getInstance();
        cal.setTime(new Date());

        int minutes = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE);

        int day = cal.get(Calendar.DAY_OF_YEAR);

        return (minutes >= getMinute(day, 15.6, 21))
                && (minutes <= getMinute(day, 21, 23.5));

//        day = 182 - day;
//        if (day < 0)
//            day *= -1;
//
//        return (minutes >= getMinute(day, 3.3, 5))
//                && (minutes <= getMinute(day, 6, 7.5));
    }

    @Override
    protected void execute() throws Throwable {

      //  printTimeRanges();

        while (!isInterrupted())
            try {

                long now = System.currentTimeMillis();
                boolean canBright = shouldBeActive();

                if (canBright && !helper.pirPower) {
                    // włączenie modułu
                    Log.info("Włączam moduł PIR");
                    helper.pirPower = true;
                    helper.writePowerState();
                    helper.pwmWrite(1);
                    powerOnTS = now;
                }

                if (!canBright && helper.pirPower) {
                    // wylaczenie modułu
                    Log.info("Wyłączam moduł PIR");
                    helper.pirPower = false;
                    helper.writePowerState();
                    helper.pwmWrite(0);
                    powerOnTS = 0;
                }

                if (flushTS > 0 && !bright) {
                    // wlaczenie
                    Log.info("Włączam zewnętrzne oświetlenie");

                    for (int i = helper.pwmValue; i <= 255; i++) {
                        helper.pwmWrite(i);
                        Thread.sleep(5);
                    }
                    bright = true;
                }

                if (bright && flushTS > 0 && now - flushTS > BRIGHT_TIME) {
                    bright = false;
                    flushTS = 0;

                    // wylaczenie
                    Log.info("Wyłączam zewnętrzne oświetlenie");
                    for (int i = helper.pwmValue; i > 0; i--) {
                        helper.pwmWrite(i);
                        Thread.sleep(15);
                        if (flushTS > 0)
                            break;
                    }

                    // jesli podczas sciemniania cos sie mienilo,
                    // to pomin sleepa 5000
                    if (flushTS > 0)
                        continue;
                }

                synchronized (flushNotify) {
                    flushNotify.wait(5000);
                }

            } catch (Throwable e) {
                Log.error(e);
            }

    }

    private static void printTimeRanges() {

        for (int day = 1; day < 366; day++) {

            int m = 182 - day;
            if (m < 0)
                m *= -1;
            int on = getMinute(day, 15.6, 21);
            int off = getMinute(day, 21, 23.5);

            String line = String.format("%03d", day)
                    + " (" + String.format("%02d", day % 31)
                    + " / " + String.format("%02d", 1 + day / 31)
                    + "): ";

            line += String.format("%02d", on / 60)
                    + ":" + String.format("%02d", on % 60)
                    + " - " + String.format("%02d", off / 60)
                    + ":" + String.format("%02d", off % 60);

            System.out.println(line);
        }
    }

}
