package com.html.tags;

import com.html.core.Element;

public class Col extends Element<Col> {

    public Col(Table parent) {
        super("col", parent);
    }
}
