package com.html.tags;

import com.html.core.Element;
import com.html.core.Node;

public class Body extends Element<Body> {

    public Body(Node parent) {
        super("body", parent);
    }
}
