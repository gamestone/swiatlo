package com.html.core;

import com.html.tags.Tag;

public class TagNC extends Tag {

    public TagNC(String name, Node parent) {
        super(name, parent);
    }

}
