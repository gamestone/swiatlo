package api;

import com.json.*;
import driver.RGB;
import driver.Terminal;
import driver.channels.*;
import java.net.InetSocketAddress;
import java.net.UnknownHostException;
import java.util.Collection;
import http.websocket.WebSocket;
import http.websocket.framing.Framedata;
import http.websocket.handshake.ClientHandshake;
import http.websocket.server.WebSocketServer;
import mlogger.Log;

public class WsServer extends WebSocketServer {

    public WsServer() throws UnknownHostException {
        super(new InetSocketAddress(8887));
    }

    @Override
    public void onOpen(WebSocket conn, ClientHandshake handshake) {

        Log.info("WS", "Podłączony " + conn.getRemoteSocketAddress());

    }

    @Override
    public void onClose(WebSocket conn, int code, String reason, boolean remote) {

        Log.info("WS", "Rozłączony " + conn.getRemoteSocketAddress());
    }

    @Override
    public void onMessage(WebSocket conn, String message) {
        try {

            JObject result = new JObject();
            result.options.singleLine(true);

            JObject obj = JSON.parse(message).asObject();
            result.add("request", obj);
            JObject res = result.object("result");

            switch (obj.getStr("action", "")) {
                case "setPwm":
                    Channel.get(obj.getStr("channel"))
                            .setValue(obj.getInt("value"),
                                    obj.getInt("speed", 0));

                    break;

                case "getPwm":
                    res.put("value", Channel.get(obj.getStr("channel"))
                            .getValue());
                    break;

                case "getGroups":
                    for (Group g : Group.all) {
                        JObject og = res.object(g.key);
                        og.put("id", g.id);
                        og.put("name", g.getName());
                        og.put("value", g.getValue());
                        JArray array = og.array("channels");
                        for (PwmChannel ch : g.channels)
                            array.add(ch.key);
                    }
                    break;

                case "updateGroups":

                    for (Terminal t : Terminal.all()) {
                        t.updateGroups();
                        Thread.sleep(200);
                    }
                    break;

                case "setRGB":

                    int value = Integer.parseInt(obj.getStr("value"), 16);
                    int b = (value) & 0xFF;
                    int g = (value >> 8) & 0xFF;
                    int r = (value >> 16) & 0xFF;

                    RGB.setRGB(r + (g << 8) + (b << 16), true, true);
                    break;

            }

            conn.send(result.toString());

        } catch (Throwable e) {
            Log.warning(e);
        }

    }

    @Override
    public void onFragment(WebSocket conn, Framedata fragment) {

    }

    @Override
    public void onError(WebSocket conn, Exception ex) {
        Log.error(ex);
    }

    public void sendToAll(String text) {
        Collection<WebSocket> con = connections();
        synchronized (con) {
            for (WebSocket c : con) {
                c.send(text);
            }
        }
    }
}
